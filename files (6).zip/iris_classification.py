"""
Task 1: Iris Flower Classification
Dataset: Kaggle "uciml/iris" (Iris.csv). Falls back to scikit-learn's built-in copy if the download isn't possible.
"""
import os
import joblib
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, ConfusionMatrixDisplay

DATA_DIR = "data"
CSV_PATH = os.path.join(DATA_DIR, "Iris.csv")
FEATURES = ["SepalLengthCm", "SepalWidthCm", "PetalLengthCm", "PetalWidthCm"]


def load_data() -> pd.DataFrame:
    """Download from Kaggle (needs ~/.kaggle/kaggle.json), else use local CSV, else sklearn."""
    os.makedirs(DATA_DIR, exist_ok=True)
    if not os.path.exists(CSV_PATH):
        try:
            from kaggle.api.kaggle_api_extended import KaggleApi
            api = KaggleApi()
            api.authenticate()
            api.dataset_download_files("uciml/iris", path=DATA_DIR, unzip=True)
            print("Downloaded dataset from Kaggle.")
        except Exception as e:
            print(f"Kaggle download unavailable ({type(e).__name__}); using scikit-learn's built-in Iris.")
            from sklearn.datasets import load_iris
            raw = load_iris(as_frame=True)
            df = raw.frame.copy()
            df.columns = FEATURES + ["target"]
            df["Species"] = df["target"].map(dict(enumerate(raw.target_names)))
            return df.drop(columns="target")
    df = pd.read_csv(CSV_PATH)
    return df.drop(columns=[c for c in ["Id"] if c in df.columns])


def main():
    df = load_data()
    print(df.head(), "\n")
    print(df.info(), "\n")
    print(df["Species"].value_counts(), "\n")

    # Exploratory plot
    sns.pairplot(df, hue="Species")
    plt.savefig("pairplot.png", dpi=120, bbox_inches="tight")
    plt.close()

    X, y = df[FEATURES], df["Species"]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    models = {
        "Logistic Regression": LogisticRegression(max_iter=200),
        "KNN (k=5)": KNeighborsClassifier(n_neighbors=5),
        "Decision Tree": DecisionTreeClassifier(random_state=42),
        "Random Forest": RandomForestClassifier(n_estimators=100, random_state=42),
        "SVM": SVC(),
    }

    results = {}
    for name, clf in models.items():
        pipe = Pipeline([("scale", StandardScaler()), ("clf", clf)])
        cv = cross_val_score(pipe, X_train, y_train, cv=5).mean()
        pipe.fit(X_train, y_train)
        acc = accuracy_score(y_test, pipe.predict(X_test))
        results[name] = (cv, acc, pipe)
        print(f"{name:20s} CV acc: {cv:.3f} | Test acc: {acc:.3f}")

    best_name = max(results, key=lambda n: results[n][0])  # pick by CV, not test set
    best = results[best_name][2]
    print(f"\nBest model (by cross-validation): {best_name}\n")

    y_pred = best.predict(X_test)
    print(classification_report(y_test, y_pred))
    ConfusionMatrixDisplay(confusion_matrix(y_test, y_pred, labels=best.classes_),
                           display_labels=best.classes_).plot(cmap="Blues")
    plt.title(f"Confusion Matrix - {best_name}")
    plt.savefig("confusion_matrix.png", dpi=120, bbox_inches="tight")
    plt.close()

    joblib.dump(best, "iris_model.joblib")

    sample = pd.DataFrame([[5.1, 3.5, 1.4, 0.2]], columns=FEATURES)
    print("Sample prediction [5.1, 3.5, 1.4, 0.2] ->", best.predict(sample)[0])


if __name__ == "__main__":
    main()
