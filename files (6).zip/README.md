# Iris Flower Classification

## Setup
```
pip install -r requirements.txt
```
## Get the dataset from Kaggle
1. Kaggle -> Settings -> API -> "Create New Token" (downloads kaggle.json)
2. Put it in `~/.kaggle/kaggle.json` (Windows: `C:\Users\<you>\.kaggle\kaggle.json`)
3. Run manually (optional; the script also does this automatically):
```
kaggle datasets download -d uciml/iris -p data --unzip
```
## Run
```
python iris_classification.py
```
Outputs: pairplot.png, confusion_matrix.png, iris_model.joblib
